package br.com.umreal.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(16, 24, 32);
    private static final int CARD = Color.rgb(28, 40, 49);
    private static final int GREEN = Color.rgb(199, 245, 167);
    private static final int WHITE = Color.rgb(245, 248, 246);
    private static final int MUTED = Color.rgb(174, 190, 199);
    private android.content.SharedPreferences prefs;
    private LinearLayout root;
    private TextView pointsValue, savedValue, goalValue, progressLabel, challengeStatus, streakValue;
    private ProgressBar goalProgress;
    private Button completeButton;
    private int points;
    private int savedCents;
    private int goalCents;
    private String lastCompleted;

    private final String[] challengeTitles = {
        "guarde R$ 1 hoje", "anote uma coisa pela qual é grato", "fique 10 minutos sem distrações",
        "separe uma moeda ou nota para economizar", "resolva um pequeno enigma", "aprenda uma curiosidade nova",
        "organize uma pequena parte do seu espaço"
    };
    private final String[] challengeDescriptions = {
        "pequenos passos também contam. registre R$ 1 na sua meta de economia.",
        "escreva algo bom que aconteceu hoje e valorize o progresso.",
        "desligue as notificações e conclua uma tarefa de cada vez.",
        "qualquer quantia conta. o importante é criar o hábito.",
        "treine a mente com um desafio rápido e mantenha a sequência.",
        "descubra algo que você ainda não sabia e compartilhe com alguém.",
        "cinco minutos de organização já podem deixar o dia mais leve."
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs = getSharedPreferences("1real_data", MODE_PRIVATE);
        points = prefs.getInt("points", 0);
        savedCents = prefs.getInt("saved_cents", 0);
        goalCents = prefs.getInt("goal_cents", 10000);
        lastCompleted = prefs.getString("last_completed", "");
        buildScreen();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(28));
        root.setBackgroundColor(BG);
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("1 REAL", 30, GREEN, true);
        brand.setLetterSpacing(0.08f);
        root.addView(brand);
        root.addView(text("pequenas missões. grandes conquistas.", 14, MUTED, false), params(0, 8));

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setPadding(0, dp(20), 0, dp(16));
        pointsValue = text("0", 24, WHITE, true);
        savedValue = text("R$ 0,00", 20, WHITE, true);
        stats.addView(statCard("PONTOS", pointsValue), new LinearLayout.LayoutParams(0, dp(96), 1));
        View gap = new View(this); stats.addView(gap, new LinearLayout.LayoutParams(dp(10), 1));
        stats.addView(statCard("GUARDADO", savedValue), new LinearLayout.LayoutParams(0, dp(96), 1));
        root.addView(stats);

        root.addView(sectionLabel("DESAFIO DE HOJE"), params(0, 8));
        LinearLayout challenge = card();
        TextView title = text("", 21, WHITE, true);
        TextView description = text("", 14, MUTED, false);
        challenge.addView(title, params(0, 8));
        challenge.addView(description, params(0, 16));
        challengeStatus = text("", 12, GREEN, true);
        challenge.addView(challengeStatus, params(0, 12));
        completeButton = button("concluir desafio");
        completeButton.setOnClickListener(v -> completeChallenge());
        challenge.addView(completeButton, params(0, 4));
        root.addView(challenge);
        int index = Math.floorMod(LocalDate.now().toEpochDay(), challengeTitles.length);
        title.setText(challengeTitles[index]);
        description.setText(challengeDescriptions[index]);

        root.addView(sectionLabel("MINHA META DE ECONOMIA"), params(0, 22));
        LinearLayout goal = card();
        goalValue = text("", 20, WHITE, true);
        progressLabel = text("", 13, MUTED, false);
        goalProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        goalProgress.setMax(1000);
        goalProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN));
        goalProgress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(57, 72, 78)));
        goalProgress.setProgress(0);
        goal.addView(text("objetivo atual", 12, MUTED, true), params(0, 7));
        goal.addView(goalValue, params(0, 8));
        goal.addView(goalProgress, params(0, 8));
        goal.addView(progressLabel, params(0, 12));
        Button addMoney = button("+ registrar economia");
        addMoney.setOnClickListener(v -> showAddSavingsDialog());
        goal.addView(addMoney, params(0, 8));
        Button changeGoal = secondaryButton("alterar meta");
        changeGoal.setOnClickListener(v -> showGoalDialog());
        goal.addView(changeGoal, params(0, 8));
        root.addView(goal);

        root.addView(sectionLabel("CONQUISTAS"), params(0, 22));
        LinearLayout achievements = card();
        streakValue = text("", 15, WHITE, true);
        achievements.addView(streakValue);
        achievements.addView(text("complete desafios para somar pontos e desbloquear marcos.", 13, MUTED, false), params(0, 8));
        root.addView(achievements);

        TextView footer = text("seus dados ficam salvos neste aparelho.", 12, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, params(0, 24));
        refreshUI();
    }

    private void completeChallenge() {
        String today = LocalDate.now().toString();
        if (today.equals(lastCompleted)) {
            Toast.makeText(this, "desafio de hoje já concluído.", Toast.LENGTH_SHORT).show();
            return;
        }
        lastCompleted = today;
        points += 10;
        int index = Math.floorMod(LocalDate.now().toEpochDay(), challengeTitles.length);
        if (index == 0) savedCents += 100;
        save(); refreshUI();
        Toast.makeText(this, "+10 pontos! boa.", Toast.LENGTH_SHORT).show();
    }

    private void showAddSavingsDialog() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setHint("ex.: 1,00");
        input.setTextColor(WHITE);
        input.setHintTextColor(MUTED);
        new AlertDialog.Builder(this).setTitle("registrar economia")
            .setMessage("quanto você guardou? informe o valor em reais.")
            .setView(input)
            .setNegativeButton("cancelar", null)
            .setPositiveButton("salvar", (d, w) -> {
                try {
                    String raw = input.getText().toString().trim().replace(".", "").replace(',', '.');
                    double amount = Double.parseDouble(raw);
                    if (amount <= 0 || amount > 1000000) throw new NumberFormatException();
                    savedCents += (int)Math.round(amount * 100.0);
                    save(); refreshUI();
                    Toast.makeText(this, "economia registrada.", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "digite um valor válido, como 1,00.", Toast.LENGTH_SHORT).show();
                }
            }).show();
    }

    private void showGoalDialog() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setText(String.format(Locale.US, "%.2f", goalCents / 100.0));
        input.setTextColor(WHITE);
        new AlertDialog.Builder(this).setTitle("alterar meta")
            .setMessage("defina sua meta em reais.")
            .setView(input).setNegativeButton("cancelar", null)
            .setPositiveButton("salvar", (d, w) -> {
                try {
                    double amount = Double.parseDouble(input.getText().toString().trim().replace(',', '.'));
                    if (amount < 1 || amount > 10000000) throw new NumberFormatException();
                    goalCents = (int)Math.round(amount * 100.0);
                    save(); refreshUI();
                } catch (Exception e) {
                    Toast.makeText(this, "digite uma meta válida.", Toast.LENGTH_SHORT).show();
                }
            }).show();
    }

    private void refreshUI() {
        pointsValue.setText(String.valueOf(points));
        savedValue.setText(money(savedCents));
        goalValue.setText(money(savedCents) + " / " + money(goalCents));
        int progress = goalCents <= 0 ? 0 : (int)Math.min(1000, (long)savedCents * 1000 / goalCents);
        goalProgress.setProgress(progress);
        progressLabel.setText(String.format(Locale.getDefault(), "%d%% da meta concluída", progress / 10));
        boolean completed = LocalDate.now().toString().equals(lastCompleted);
        challengeStatus.setText(completed ? "DESAFIO CONCLUÍDO HOJE" : "+10 pontos por concluir");
        completeButton.setText(completed ? "concluído hoje" : "concluir desafio");
        completeButton.setEnabled(!completed);
        completeButton.setAlpha(completed ? 0.55f : 1f);
        String achievement;
        if (points >= 100) achievement = "🏆 mestre das missões · " + points + " pontos";
        else if (points >= 50) achievement = "★ dedicado · " + points + " pontos";
        else if (points >= 10) achievement = "✓ primeira conquista desbloqueada · " + points + " pontos";
        else achievement = "🔒 primeira conquista: alcance 10 pontos";
        streakValue.setText(achievement);
    }

    private void save() {
        prefs.edit().putInt("points", points).putInt("saved_cents", savedCents)
            .putInt("goal_cents", goalCents).putString("last_completed", lastCompleted).apply();
    }

    private String money(int cents) {
        NumberFormat nf = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
        return nf.format(cents / 100.0);
    }

    private LinearLayout statCard(String label, TextView value) {
        LinearLayout box = card();
        box.addView(text(label, 11, MUTED, true), params(0, 8));
        box.addView(value);
        return box;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        GradientDrawable bg = new GradientDrawable(); bg.setColor(CARD); bg.setCornerRadius(dp(18));
        box.setBackground(bg);
        return box;
    }

    private TextView sectionLabel(String value) {
        TextView t = text(value, 12, GREEN, true); t.setLetterSpacing(0.07f); return t;
    }
    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(BG); b.setTextSize(14); b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setBackground(tint(GREEN)); return b;
    }
    private Button secondaryButton(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(WHITE); b.setTextSize(14); b.setAllCaps(false);
        b.setBackground(tint(Color.rgb(54, 70, 77))); return b;
    }
    private GradientDrawable tint(int color) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(12)); return d;
    }
    private LinearLayout.LayoutParams params(int width, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width == 0 ? -1 : width, -2);
        p.topMargin = dp(top); return p;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
