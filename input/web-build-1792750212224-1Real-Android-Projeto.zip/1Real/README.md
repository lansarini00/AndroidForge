# 1 Real — primeira versão Android

Projeto Android nativo em Java, com interface escura e detalhes verdes. O ícone do app usa a moeda de R$ 1 escolhida para o projeto.

## Recursos incluídos
- desafio diário que muda conforme a data;
- concluir um desafio uma vez por dia e receber 10 pontos;
- saldo de pontos e dinheiro economizado;
- registrar valores manualmente na meta de economia;
- configurar o valor da meta;
- progresso visual da meta e marcos de conquistas;
- dados salvos localmente no aparelho com SharedPreferences;
- ícone do aplicativo para Android, incluindo recursos de launcher adaptativo.

## Abrir o projeto
1. Em um computador, instale o Android Studio e o JDK 17.
2. Abra a pasta `1Real` no Android Studio.
3. Aguarde a sincronização do Gradle e execute em um aparelho Android ou emulador.
4. Para publicar na Play Store, gere um Android App Bundle (`.aab`) assinado em **Build > Generate Signed Bundle / APK**.

## Importante
- Esta é uma primeira versão local: não há conta, sincronização em nuvem, anúncios ou compras dentro do app.
- O app não cobra R$ 1 por conta própria. O preço de R$ 1 deve ser configurado na Play Console ao publicar o aplicativo como pago.
- A pasta contém o código-fonte; não é um APK pronto para instalar. Este ambiente não tem Android SDK/Gradle configurado para confirmar uma compilação. Compile e teste no Android Studio antes de publicar.
- Dados locais podem ser apagados ao limpar os dados do app ou desinstalá-lo.
